/*
 * Hello.java
 *
 * Created on January 19, 2007, 1:22 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author sang
 */
public class Hello {
    
    /** Creates a new instance of Hello */
    public Hello() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static voidx main(String[] args) {
        // Print the string "Hello world" on screen
        System.out.println("This is my first Java program!");
    }
    
}
