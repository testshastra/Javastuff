/*
 * Main.java
 *
 * Created on February 12, 2007, 10:08 AM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication116;

/**
 *
 * @author sang
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NewInterface x = new String();
    }
    
}
