/*
 * Main.java
 *
 * Created on February 12, 2007, 1:48 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication118;

/**
 *
 * @author sang
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Throwable  {
        
        NewClass x = new NewClass();
    }
    
}
