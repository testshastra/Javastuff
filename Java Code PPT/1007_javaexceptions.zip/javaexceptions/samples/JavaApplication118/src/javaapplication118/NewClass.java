/*
 * NewClass.java
 *
 * Created on February 12, 2007, 1:51 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication118;

/**
 *
 * @author sang
 */
public class NewClass {
    
    /** Creates a new instance of NewClass */
    public NewClass()throws NewException {
        throw new NewException();
    }
    
}
