/*
 * NewException.java
 *
 * Created on February 12, 2007, 1:49 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package javaapplication118;

/**
 *
 * @author sang
 */
public class NewException extends Exception{
    
    /**
     * Creates a new instance of NewException
     */
    public NewException() {
    }
    
}
