/*
 * DummyClass.java
 *
 * Created on January 27, 2007, 4:20 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author sang
 */
public class DummyClass {
    
    /** Creates a new instance of DummyClass */
    public DummyClass() {
    }
    
}
