public class Variables {
    
    // Static variables
    static int staticintA = 10;
    static String staticStringB ="I am static string";
    
    // Instance variables
    int instanceintA = 20;
    String instanceStringB = "I am instance string";
    
}
