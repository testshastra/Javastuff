
public class ThisReferenceExample {
    
    /** Creates a new instance of ThisReferenceExample */
    public ThisReferenceExample() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       DummyClass d1 = new DummyClass();
       d1.mymethod1();
    }
}
