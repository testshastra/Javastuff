
package mypeopleexample;

public class InternationalStudent extends Student {
    
    /** Creates a new instance of InternationalStudent */
    public InternationalStudent() {
    }
    
    private String country;

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
}
