
package mypeopleexample;

public class Main {
    
    public static void main(String[] args) {
        
        // Create an object instance of 
        // InternationalStudent class.
        System.out.println("---- About to create an object instance of InternationalStudent class...");
        InternationalStudent internationalStudent1 =
                new InternationalStudent();
        
        // Create an object instance of 
        // Teacher class.
         System.out.println("---- About to create an object instance of Teacher class...");
        Teacher teacher1 = new Teacher();
        
    }
}
