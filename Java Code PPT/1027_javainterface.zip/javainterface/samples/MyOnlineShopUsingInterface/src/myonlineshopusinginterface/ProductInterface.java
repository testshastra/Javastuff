
package myonlineshopusinginterface;

public interface ProductInterface {
    public double computeSalePrice();
    public double getRegularPrice();
    public void setRegularPrice(double regularPrice);
}
