
package mypersoninterfaceproject;

public interface AnotherInterfaceExample {
    
    // Measure person's intelligence
    int measureIntelligence(String name);
    
}
