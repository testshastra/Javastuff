
package mypersoninterfaceproject;

public class PersonAnother2 extends Person implements PersonInterfaceAnother{
    
    PersonAnother2(){
        
    }
    
    // Implement a new method
    public void newMethod(){
        // Some code
    }
}
