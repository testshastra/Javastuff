
package mypersoninterfaceproject;

public interface PersonInterfaceAnother {
    
    // Add another method to the interface
    void newMethod();
    
}
