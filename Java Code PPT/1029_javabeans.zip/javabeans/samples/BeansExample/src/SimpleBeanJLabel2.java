

public class SimpleBeanJLabel2 extends SimpleBeanJLabel {
   
    private String labelType;

    public String getLabelType() {
        return labelType;
    }

    public void setLabelType(String labelType) {
        this.labelType = labelType;
    }

}
