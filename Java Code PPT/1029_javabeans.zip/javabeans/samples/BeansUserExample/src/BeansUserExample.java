/*
 * BeansUserExample.java
 *
 * Created on March 3, 2007, 3:05 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

/**
 *
 * @author sang
 */
public class BeansUserExample {
    
    /** Creates a new instance of BeansUserExample */
    public BeansUserExample() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
