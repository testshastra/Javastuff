import java.util.EventObject;

public interface MyEventListenerInterface { 
    public void somethingHappened(MyEvent event);
}
