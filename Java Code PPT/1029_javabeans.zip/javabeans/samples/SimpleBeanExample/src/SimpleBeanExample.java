
public class SimpleBeanExample {
    
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
