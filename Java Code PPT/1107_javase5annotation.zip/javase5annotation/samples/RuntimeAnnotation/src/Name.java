import java.lang.annotation.*;

public @interface Name {
  String first();
  String last();
}